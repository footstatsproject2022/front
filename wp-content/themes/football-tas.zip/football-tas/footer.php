<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Titan
 * @since 3.0.0
 */

?>

<footer class="site-footer">
    <div class="container-fluid">
        <p class="m-0">&copy; Football 2022</p>
    </div>
</footer>
<!-- #colophon -->


<?php wp_footer(); ?>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
AOS.init();
</script>

<style>
.wpforms-field-medium{
    max-width:100% !important;
}  
body.page-template-home-page footer.site-footer{
    margin:0px !important;
}
@media(max-width:767px){
    body.page-template-home-page header#main-nav{
        position:relative !important;
        background: #69ca63;
        background: linear-gradient(90deg, #69ca63 0%, #4fb06d 50%);
        padding-bottom: 15px; 
    }
}

</style>

</body>
</html>
