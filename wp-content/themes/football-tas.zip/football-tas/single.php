<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Titan
 * @since 3.0.0
 */

 get_header(); ?>

 <?php get_template_part('blocks/blog/blogsingle', '1') ?>

 <?php get_footer(); ?>
