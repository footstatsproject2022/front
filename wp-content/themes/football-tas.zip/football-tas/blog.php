<?php
/*
Template Name: Blog
*/
?>

<?php get_header(); ?>

<!-- For pagination please make sure you active WP PageNavi -->
<?php get_template_part('blocks/blog/blog', '1') ?>

<?php get_footer(); ?>
